<?php
// Connect to the database
$host = "localhost";
$dbname = "scannsavor";
$username = "root";
$password = "";

try {
  $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
  echo "Connection failed: " . $e->getMessage();
  die();
}

// Get data from the form
$userId = $_POST['userId'];
$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];
$position = $_POST['position'];
$role = $_POST['role'];

// Update user data in the database
$query = "UPDATE users SET name=?, email=?, password=?, position=?, role=? WHERE id=?";
$stmt = $pdo->prepare($query);
$stmt->execute([$name, $email, $password, $position, $role, $userId]);

echo "User data updated successfully";
?>
