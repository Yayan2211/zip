<!-- delete_user.php -->
<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST["id"])) {
        // Get the user ID from the AJAX request
        $userId = $_POST["id"];

        // Connect to the database (modify as needed)
        $pdo = new PDO("mysql:host=localhost;dbname=scannsavor", "root", "");

        // Prepare and execute the delete query
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = :id");
        $stmt->bindParam(":id", $userId, PDO::PARAM_INT);
        if ($stmt->execute()) {
            echo "User deleted successfully.";
        } else {
            header("HTTP/1.1 500 Internal Server Error");
            echo "Error deleting the user.";
        }
    } else {
        header("HTTP/1.1 400 Bad Request");
        echo "Invalid request";
    }
}
?>
