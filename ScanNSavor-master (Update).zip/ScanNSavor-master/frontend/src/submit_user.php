<?php
// Retrieve data from the POST request
$name = $_POST["name"];
$email = $_POST["email"];
$password = $_POST["password"];
$position = $_POST["position"];
$role = $_POST["role"];

try {
    // Database credentials
    $hostname = "localhost";
    $username = "root";
    $db_password = "";
    $dbname = "scannsavor";

    // Create a new PDO instance
    $connect = new PDO("mysql:host=$hostname;dbname=$dbname", $username, $db_password);

    // Set the PDO error mode to exception
    $connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Prepare the SQL statement
    $sql = "INSERT INTO users (name, email, password, position, role) VALUES (:name, :email, :password, :position, :role)";
    $stmt = $connect->prepare($sql);

    // Bind parameters
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':password', $password);
    $stmt->bindParam(':position', $position);
    $stmt->bindParam(':role', $role);

    // Execute the statement
    $stmt->execute();

    echo "User added successfully";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

// Close the database connection
$connect = null;
?>


